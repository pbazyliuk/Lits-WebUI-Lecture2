This is Essays 1743, a font by John Stracke, based on the typeface
used in a 1743 English translation of Montaigne's Essays.  The font is
released under the terms of the GNU Lesser General Public License (see
the COPYING file).  At present (version 0.2), it contains 817
characters: all of ASCII, Latin-1, and Latin Extended A; some of Latin
Extended B (basically, the ones that are more or less based on Roman
letters); and a variety of other characters, such as oddball
punctuation, numerals, etc.

TrueType and PostScript forms are available.

For the purposes of the LGPL, the source file is Essays1743.sfd (the
pfaedit source), which should be included in this archive.
